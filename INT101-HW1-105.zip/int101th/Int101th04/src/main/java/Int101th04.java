
public class Int101th04 {

    public static void main(String[] args) {
        System.out.println();
    }
}
