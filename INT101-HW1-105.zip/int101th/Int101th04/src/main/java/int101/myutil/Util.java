package int101.myutil;

public  final class Util {
    public static double computeAreaofCircle(double radius){
        double area; //variable declaration
        area = Math.PI * radius * radius; //variable assignment
        return area;
    }
    // computePerimeterOfCircle()
    //computeDiagonalOfRight
}
